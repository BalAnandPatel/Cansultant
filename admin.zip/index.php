<?php 
 
 header('location:https://ssegr.org.in/website/index.php');

 ?>