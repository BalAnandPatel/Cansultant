<?php
date_default_timezone_set('Asia/Kolkata');

$BASE_URL="https://ssegr.org.in";
$URL=$BASE_URL."/api/src/";
$EXAM_NAME="UPPCL EXAMINATION";

$ADMIN_IMG_PATH=$BASE_URL."/user/img/";


 $HOME="index.php";

$SECRET_KEY = "dKgLINTEL2013aN99840$@";  
$ISSUER_CLAIM = "GLINTEL TECHNOLOGY PVT LTD"; // this can be the servername
$AUDIENCE_CLAIM = "PSP NEWS";


$LOGIN_SUCCESS_MSG="Login Successful";
$LOGIN_FAILED_MSG="Request Failed";

?>